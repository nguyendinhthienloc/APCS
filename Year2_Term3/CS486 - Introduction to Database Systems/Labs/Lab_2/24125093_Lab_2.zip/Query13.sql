SELECT I.instructor_id, I.instructor_name
FROM Instructor I
WHERE NOT EXISTS (
    SELECT 1
    FROM Teaching T
    JOIN Section SEC ON T.section_id = SEC.section_id
    JOIN Course C ON SEC.course_id = C.course_id
    WHERE T.instructor_id = I.instructor_id
      AND C.department_id <> I.department_id
)
AND EXISTS (
    SELECT 1
    FROM Teaching T
    WHERE T.instructor_id = I.instructor_id
);
