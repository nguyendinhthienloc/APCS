SELECT I.instructor_id, I.instructor_name
FROM Instructor I
JOIN Department D ON I.department_id = D.department_id
WHERE D.department_name = 'Software Engineering'
  AND I.instructor_id NOT IN (
      SELECT T.instructor_id
      FROM Teaching T
      WHERE T.teaching_role = 'TA'
  );
