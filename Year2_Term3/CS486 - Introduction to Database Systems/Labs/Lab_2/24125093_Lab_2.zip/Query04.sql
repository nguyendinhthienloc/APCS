SELECT C.course_id, C.course_name, P_C.course_name AS prerequisite_name
FROM Course C
LEFT JOIN Prerequisite P ON C.course_id = P.course_id
LEFT JOIN Course P_C ON P.prerequisite_id = P_C.course_id
WHERE C.department_id = 'IS';
