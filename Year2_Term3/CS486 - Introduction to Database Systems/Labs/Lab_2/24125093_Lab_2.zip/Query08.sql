SELECT instructor_id
FROM Teaching
WHERE teaching_role = 'Lecturer'
INTERSECT
SELECT instructor_id
FROM Teaching
WHERE teaching_role = 'TA';
