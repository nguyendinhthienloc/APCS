SELECT D.department_id, D.department_name
FROM Department D
JOIN Instructor I ON D.department_id = I.department_id
GROUP BY D.department_id, D.department_name
HAVING AVG(I.salary) >= ALL (
    SELECT AVG(I2.salary)
    FROM Instructor I2
    GROUP BY I2.department_id
);
