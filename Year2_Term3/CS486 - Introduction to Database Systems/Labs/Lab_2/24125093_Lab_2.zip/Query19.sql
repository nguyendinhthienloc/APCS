SELECT DISTINCT I.instructor_id, I.instructor_name
FROM Instructor I
JOIN Teaching T ON I.instructor_id = T.instructor_id
WHERE T.section_id IN (
    SELECT T2.section_id
    FROM Instructor I2
    JOIN Teaching T2 ON I2.instructor_id = T2.instructor_id
    WHERE I2.instructor_name LIKE '%John%'
);
