SELECT DISTINCT I.instructor_name, I.salary * 1.1 AS NewSalary
FROM Instructor I
JOIN Teaching T ON I.instructor_id = T.instructor_id
JOIN Section SEC ON T.section_id = SEC.section_id
WHERE SEC.course_id = 'CS07';
