SELECT S.student_id, S.student_name, S.gender, S.birthday, S.student_class, S.department_id
FROM Student S
JOIN GradeReport GR ON S.student_id = GR.student_id
JOIN Section SEC ON GR.section_id = SEC.section_id
WHERE SEC.course_id = 'CS07'
  AND SEC.semester = 'Fall'
  AND SEC.school_year = 2022;
