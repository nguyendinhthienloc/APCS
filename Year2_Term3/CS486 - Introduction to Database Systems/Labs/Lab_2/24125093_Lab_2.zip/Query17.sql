SELECT I1.instructor_id, I1.instructor_name, I1.department_id, I1.salary
FROM Instructor I1
WHERE I1.salary >= ALL (
    SELECT I2.salary
    FROM Instructor I2
    WHERE I2.department_id = I1.department_id
);
