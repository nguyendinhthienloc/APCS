SELECT student_id, student_name, birthday, student_class, department_id
FROM Student
WHERE YEAR(birthday) BETWEEN 2000 AND 2005;
