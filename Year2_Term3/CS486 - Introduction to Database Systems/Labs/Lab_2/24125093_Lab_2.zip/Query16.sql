SELECT D.department_id, D.department_name, AVG(I.salary) AS AvgSalary
FROM Department D
LEFT JOIN Instructor I ON D.department_id = I.department_id
GROUP BY D.department_id, D.department_name;
