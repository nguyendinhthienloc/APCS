SELECT D.department_name, I.instructor_name, C.course_id, C.course_name
FROM Instructor I
JOIN Department D ON I.department_id = D.department_id
JOIN Teaching T ON I.instructor_id = T.instructor_id
JOIN Section SEC ON T.section_id = SEC.section_id
JOIN Course C ON SEC.course_id = C.course_id
WHERE T.teaching_role = 'Lecturer'
ORDER BY D.department_name ASC, I.instructor_name ASC;
