SELECT C.course_id, C.course_name
FROM Course C
JOIN Section SEC ON C.course_id = SEC.course_id
JOIN Teaching T ON SEC.section_id = T.section_id
GROUP BY C.course_id, C.course_name
HAVING COUNT(DISTINCT T.instructor_id) = (
    SELECT MAX(instructor_count)
    FROM (
        SELECT COUNT(DISTINCT T2.instructor_id) AS instructor_count
        FROM Course C2
        JOIN Section SEC2 ON C2.course_id = SEC2.course_id
        JOIN Teaching T2 ON SEC2.section_id = T2.section_id
        GROUP BY C2.course_id
    ) AS Sub
);
