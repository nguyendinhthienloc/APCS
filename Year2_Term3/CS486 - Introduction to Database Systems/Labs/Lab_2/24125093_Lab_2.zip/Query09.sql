SELECT S.student_id, S.student_name
FROM Student S
WHERE S.student_id IN (
    SELECT GR.student_id
    FROM GradeReport GR
    JOIN Section SEC ON GR.section_id = SEC.section_id
    WHERE SEC.course_id = 'CS03'
      AND SEC.semester = 'Fall'
      AND SEC.school_year = 2022
      AND GR.grade_ABC <> 'F'
)
AND S.student_id IN (
    SELECT GR.student_id
    FROM GradeReport GR
    JOIN Section SEC ON GR.section_id = SEC.section_id
    WHERE SEC.course_id = 'CS04'
      AND SEC.semester = 'Fall'
      AND SEC.school_year = 2022
      AND GR.grade_ABC = 'F'
);
