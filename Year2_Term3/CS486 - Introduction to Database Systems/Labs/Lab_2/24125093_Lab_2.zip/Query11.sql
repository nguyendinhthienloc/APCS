SELECT school_year, semester, COUNT(DISTINCT course_id) AS number_of_courses
FROM Section
GROUP BY school_year, semester;
