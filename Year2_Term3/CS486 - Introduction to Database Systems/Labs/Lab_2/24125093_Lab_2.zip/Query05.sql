SELECT I.instructor_id, I.instructor_name, I.phone, I.department_id, I.salary
FROM Instructor I
JOIN Department D ON I.department_id = D.department_id
WHERE D.department_name = 'Computer Science'
  AND I.salary BETWEEN 2000 AND 3000;
