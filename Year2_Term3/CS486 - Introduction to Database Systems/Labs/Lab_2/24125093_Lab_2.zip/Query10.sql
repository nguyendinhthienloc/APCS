SELECT S.student_id, S.student_name
FROM Student S
JOIN GradeReport GR ON S.student_id = GR.student_id
WHERE GR.grade_ABC <> 'F'
GROUP BY S.student_id, S.student_name
HAVING COUNT(DISTINCT GR.section_id) > 2;
