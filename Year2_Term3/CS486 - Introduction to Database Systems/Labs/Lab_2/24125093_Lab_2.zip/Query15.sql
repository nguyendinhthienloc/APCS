WITH RankedStudents AS (
    SELECT GR.section_id, GR.student_id, S.student_name, GR.grade_100,
           RANK() OVER (PARTITION BY GR.section_id ORDER BY GR.grade_100 DESC) AS rnk
    FROM GradeReport GR
    JOIN Student S ON GR.student_id = S.student_id
)
SELECT section_id, student_id, student_name, grade_100
FROM RankedStudents
WHERE rnk = 1;
