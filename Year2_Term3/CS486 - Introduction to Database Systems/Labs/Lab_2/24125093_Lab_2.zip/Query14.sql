SELECT S.student_id, S.student_name, D.department_id, D.department_name, COUNT(DISTINCT C.course_id) AS course_count
FROM Student S
CROSS JOIN Department D
LEFT JOIN GradeReport GR ON S.student_id = GR.student_id
LEFT JOIN Section SEC ON GR.section_id = SEC.section_id
LEFT JOIN Course C ON SEC.course_id = C.course_id AND C.department_id = D.department_id
GROUP BY S.student_id, S.student_name, D.department_id, D.department_name;
